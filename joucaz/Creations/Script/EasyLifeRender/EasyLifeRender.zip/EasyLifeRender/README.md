# Easy Life Render

**Version:** 1.0.0

## Description
Easy Life Render is a Blender addon that allows users to add lights and a camera around selected objects based on various presets.

## Installation
1. Download the ZIP file of the addon.
2. In Blender, go to `Edit > Preferences > Add-ons`.
3. Click on `Install from Disk`, select the downloaded ZIP file, and install it.
4. Enable the addon in the list of addons.

## Usage
1. Select one or more objects in the scene.
2. Go to the `EasyLifeRender` panel in the 3D view.
3. Choose a light preset and click on `Add Preset Lights`.

## Available Presets
- Basic 3 Point Lights
- French Lights
- Tamised Lights
- Caliente Lights
- Samba Do Brazil Lights

## Contributing
If you would like to contribute to this project, please contact me via my website joudcazeaux.fr

## License
This project is licensed under the MIT License.
